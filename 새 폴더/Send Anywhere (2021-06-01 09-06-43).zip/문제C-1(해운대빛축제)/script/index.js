

$(function(){
    
    $('.main').mouseenter(function(){
        $(this).children('.subMenu').stop().slideDown();
    })
    
    $('.main').mouseleave(function(){
        $(this).children('.subMenu').stop().slideUp();
    })
    
})












